import { useState, useEffect, useMemo, useRef, createContext, useContext, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { useKpk, fmtClock } from "@/lib/kpkStore";
import { sfx } from "@/lib/sounds";
import { FACTIONS } from "@/lib/kpkData";
import type { Screen } from "@/lib/kpkData";
import { ListTodo, TrendingUp, Radar, BarChart3 } from "lucide-react";
import LobbyPlayersPanel from "./LobbyPlayersPanel";
import CompletedMissionsModal from "./CompletedMissionsModal";
import ScoreAdminModal from "./ScoreAdminModal";

export const SCREEN_TITLES: Partial<Record<Screen, string>> = {
  main: "КПК",
  missions: "Місії",
  upgrades: "Прокачки",
  news: "Новини",
  score: "Бали",
  timer: "Таймер",
};

export function AnimatedItem({ children, index = 0, className = "" }: { children: ReactNode; index?: number; className?: string }) {
  return (
    <div className={`hdr-animated ${className}`} style={{ opacity: 0, animation: `hud-screen-in 0.45s cubic-bezier(0.2,0.8,0.2,1) ${index * 0.1 + 0.1}s both` }}>
      {children}
    </div>
  );
}

function HeaderTimer() {
  const { go, turnSeconds, screen } = useKpk();
  const [blink, setBlink] = useState(false);
  const ending = turnSeconds <= 30;

  useEffect(() => {
    if (turnSeconds > 0 && turnSeconds % 60 === 0) {
      setBlink(true);
      const t = setTimeout(() => setBlink(false), 600);
      return () => clearTimeout(t);
    }
  }, [turnSeconds]);

  if (screen === "timer") return null;

  return (
    <button
      onClick={() => { sfx.click(); go("timer"); }}
      aria-label="Перейти до таймера"
      className={[
        "hud-mono tabular-nums px-2 py-1 transition-all select-none shrink-0",
        ending
          ? "text-[color:var(--hud-red)]"
          : blink
          ? "text-[color:var(--hud-amber-glow)] scale-110"
          : "text-[color:var(--hud-amber-glow)] hud-flicker",
      ].join(" ")}
      style={{ fontSize: 24 }}
    >
      <span className={ending ? "hud-pulse-red" : ""}>
        {fmtClock(turnSeconds)}
      </span>
    </button>
  );
}


function BurgerMenu() {
  const {
    roomCode,
    players,
    playerId,
    isHost,
    logout,
    debugBypassTurnLock,
    setDebugBypassTurnLock,
    useLegacyNewsSpawn,
    setUseLegacyNewsSpawn,
    isTestSession,
    allMissions,
    cheatGenerateNews,
    cheatAddScore,
  } = useKpk();
  const [open, setOpen] = useState(false);
  const [confirmExit, setConfirmExit] = useState(false);
  const [muted, setMuted] = useState<boolean>(sfx.isMuted());
  const [missionPoolOpen, setMissionPoolOpen] = useState(false);
  const [reorderOpen, setReorderOpen] = useState(false);
  const [completedMissionsOpen, setCompletedMissionsOpen] = useState(false);
  const [scoreAdminOpen, setScoreAdminOpen] = useState(false);

  const missionPoolGroups = useMemo(() => {
    const classes = ["Атака", "Захист", "Економіка", "Лут"] as const;
    return classes.map((cls) => {
      const byLevel: Record<1 | 2 | 3, typeof allMissions> = { 1: [], 2: [], 3: [] };
      for (const mission of allMissions) {
        if (mission.cls === cls) byLevel[mission.level].push(mission);
      }
      return { cls, byLevel };
    });
  }, [allMissions]);

  return (
    <>
      <button
        onClick={() => { sfx.click(); setOpen(true); }}
        aria-label="Меню сесії"
        className="shrink-0 flex flex-col gap-[5px] justify-center items-center w-10 h-10 border border-[color:var(--hud-amber)]/40 bg-[color:var(--surface-3)] hover:border-[color:var(--hud-amber)] transition-all"
      >
        <span className="block h-[2px] w-5 bg-[color:var(--hud-amber)]" />
        <span className="block h-[2px] w-5 bg-[color:var(--hud-amber)]" />
        <span className="block h-[2px] w-5 bg-[color:var(--hud-amber)]" />
      </button>

      {open && createPortal(
        <div className="fixed inset-0 z-[99999]">
          <div className="absolute inset-0 bg-black/75 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div
            className="absolute left-0 z-[100000] flex flex-col w-72 max-w-[85vw] bg-[color:var(--surface-1)] border-r-2 border-[color:var(--hud-amber)]/50"
            style={{
              top: "env(safe-area-inset-top)",
              height: "75vh",
              paddingTop: "0",
              paddingBottom: "env(safe-area-inset-bottom)",
              animation: "slide-in-left 0.22s cubic-bezier(0.2,0.8,0.2,1) both",
            }}
          >
            <div className="flex flex-col flex-1 p-5 gap-5 overflow-hidden">
              <div className="flex items-center justify-between border-b border-[color:var(--hud-amber)]/30 pb-3">
                <div className="hud-label text-[color:var(--hud-amber)] tracking-widest text-sm">// СЕСІЯ</div>
                <button
                  onClick={() => setOpen(false)}
                  className="hud-mono text-xl leading-none text-[color:var(--muted-foreground)] hover:text-[color:var(--foreground)] w-8 h-8 flex items-center justify-center"
                >
                  ✕
                </button>
              </div>

              {roomCode && (
                <div style={{ opacity: 0, animation: "hud-screen-in 0.35s cubic-bezier(0.2,0.8,0.2,1) 0.05s both" }}>
                  <div className="hud-label text-[0.6rem] text-[color:var(--hud-cyan)] mb-1">
                    // КОД КІМНАТИ {isHost ? "· HOST" : ""}
                  </div>
                  <div className="hud-title text-3xl tracking-[0.4em] text-[color:var(--hud-cyan)]">{roomCode}</div>
                </div>
              )}

              <div className="flex-1 overflow-y-auto hud-scroll">
                <div className="hud-label text-[0.6rem] mb-2">// ГРАВЦІ</div>
                <div className="flex flex-col gap-2">
                  {players.map((p, i) => (
                    <div
                      key={p.id}
                      style={{ opacity: 0, animation: `hud-screen-in 0.35s cubic-bezier(0.2,0.8,0.2,1) ${0.1 + i * 0.07}s both` }}
                      className={`hud-mono text-[0.75rem] flex items-center gap-2 border px-3 py-2.5 ${
                        p.id === playerId
                          ? "border-[color:var(--hud-amber)] text-[color:var(--hud-amber)] bg-[color:var(--hud-amber)]/5"
                          : "border-[color:var(--hud-amber)]/25 text-[color:var(--muted-foreground)]"
                      }`}
                    >
                      <span
                        className="inline-block h-2 w-2 rounded-full shrink-0"
                        style={{ background: FACTIONS[p.faction] ?? "#fff" }}
                      />
                      {p.nickname}
                      {isTestSession && (
                        <div className="ml-auto flex items-center gap-1">
                          <button
                            onClick={(e) => { e.stopPropagation(); sfx.click(); cheatAddScore(p.id, 1); }}
                            className="h-5 rounded border border-[color:var(--hud-amber)]/30 px-1.5 text-[0.55rem] text-[color:var(--hud-amber)]"
                            aria-label={`Додати +1 бал ${p.nickname} рівень I`}
                          >
                            +I
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); sfx.click(); cheatAddScore(p.id, 2); }}
                            className="h-5 rounded border border-[color:var(--hud-amber)]/30 px-1.5 text-[0.55rem] text-[color:var(--hud-amber)]"
                            aria-label={`Додати +1 бал ${p.nickname} рівень II`}
                          >
                            +II
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); sfx.click(); cheatAddScore(p.id, 3); }}
                            className="h-5 rounded border border-[color:var(--hud-amber)]/30 px-1.5 text-[0.55rem] text-[color:var(--hud-amber)]"
                            aria-label={`Додати +1 бал ${p.nickname} рівень III`}
                          >
                            +III
                          </button>
                        </div>
                      )}
                      {p.id === playerId && (
                        <span className="ml-auto text-[0.6rem] text-[color:var(--hud-green)]">● ВИ</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ opacity: 0, animation: "hud-screen-in 0.25s cubic-bezier(0.2,0.8,0.2,1) 0.05s both" }}>
                <button
                  onClick={() => { const m = !muted; setMuted(m); sfx.setMuted(m); if (!m) sfx.click(); }}
                  className="hud-btn hud-btn-ghost w-full"
                  aria-label={muted ? "Увімкнути звук" : "Вимкнути звук"}
                >
                  {muted ? "🔇 Звук" : "🔊 Звук"}
                </button>
              </div>

              {isHost && (
                <div style={{ opacity: 0, animation: "hud-screen-in 0.25s cubic-bezier(0.2,0.8,0.2,1) 0.07s both" }}>
                  <div className="hud-label text-[0.6rem] text-[color:var(--hud-amber)] mb-2">// ХОСТ</div>
                  <button
                    onClick={() => { sfx.click(); setReorderOpen(true); }}
                    className="hud-btn hud-btn-ghost w-full"
                  >
                    👥 Порядок гравців
                  </button>
                  <button
                    onClick={() => { sfx.click(); setCompletedMissionsOpen(true); }}
                    className="hud-btn hud-btn-ghost mt-2 w-full"
                  >
                    📋 Виконані місії
                  </button>
                  <button
                    onClick={() => { sfx.click(); setScoreAdminOpen(true); }}
                    className="hud-btn hud-btn-ghost mt-2 w-full"
                  >
                    🎯 Керування балами
                  </button>
                </div>
              )}

              {isTestSession && (
                <div style={{ opacity: 0, animation: "hud-screen-in 0.25s cubic-bezier(0.2,0.8,0.2,1) 0.08s both" }}>
                  <div className="hud-label text-[0.6rem] text-[color:var(--hud-red)] mb-2">// ТЕСТ</div>
                  <button
                    onClick={() => { sfx.click(); setDebugBypassTurnLock(!debugBypassTurnLock); }}
                    className="hud-btn hud-btn-ghost w-full"
                    aria-pressed={debugBypassTurnLock}
                    aria-label={debugBypassTurnLock ? "Вимкнути обхід обмеження ходу" : "Увімкнути обхід обмеження ходу"}
                  >
                    {debugBypassTurnLock ? "☑ Дозволити поза чергою" : "☐ Дозволити поза чергою"}
                  </button>
                  <button
                    onClick={() => { sfx.click(); setUseLegacyNewsSpawn(!useLegacyNewsSpawn); }}
                    className="hud-btn hud-btn-ghost mt-2 w-full"
                    aria-pressed={useLegacyNewsSpawn}
                    aria-label={useLegacyNewsSpawn ? "Вимкнути старий спавн новин" : "Увімкнути старий спавн новин"}
                  >
                    {useLegacyNewsSpawn ? "☑ Старий спавн новин" : "☐ Старий спавн новин"}
                  </button>
                  <button
                    onClick={() => { sfx.click(); setMissionPoolOpen(true); }}
                    className="hud-btn hud-btn-ghost mt-2 w-full"
                  >
                    🗂 Переглянути всі місії
                  </button>
                  <button
                    onClick={() => { sfx.click(); cheatGenerateNews(); }}
                    className="hud-btn hud-btn-ghost mt-2 w-full"
                  >
                    ⟳ Нова новина (тест)
                  </button>
                </div>
              )}

              <button
                onClick={() => { sfx.click(); setOpen(false); setConfirmExit(true); }}
                className="hud-btn hud-btn-ghost w-full"
              >
                ↶ Вийти з сесії
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {missionPoolOpen && createPortal(
        <div className="fixed inset-0 z-[100001] flex items-center justify-center bg-black/85 px-3 py-4 backdrop-blur-sm">
          <div
            className="hud-panel-corners-4 relative flex max-h-[86vh] w-full max-w-3xl flex-col border border-[color:var(--hud-amber)]/60 bg-[color:var(--surface-2)] p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="corner tl" />
            <span className="corner tr" />
            <span className="corner bl" />
            <span className="corner br" />
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="hud-label text-[0.6rem] text-[color:var(--hud-amber)]">// ПУЛ МІСІЙ</div>
                <div className="hud-title mt-1 text-lg text-[color:var(--hud-amber)]">Повний пул місій</div>
              </div>
              <button
                onClick={() => setMissionPoolOpen(false)}
                className="hud-mono text-xl leading-none text-[color:var(--muted-foreground)] hover:text-[color:var(--foreground)]"
              >
                ✕
              </button>
            </div>
            <div className="mt-4 overflow-y-auto hud-scroll pr-1">
              {missionPoolGroups.map(({ cls, byLevel }) => (
                <details key={cls} className="mb-4 border border-[color:var(--hud-amber)]/20 bg-[color:var(--surface-1)]/70">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-3 p-3">
                    <div className="flex items-center gap-2">
                      <div className="hud-label text-[0.6rem] text-[color:var(--hud-amber)]">{cls}</div>
                      <div className="hud-mono text-[0.6rem] text-[color:var(--muted-foreground)]">
                        {Object.values(byLevel).flat().length} місій
                      </div>
                    </div>
                    <div className="hud-mono text-[0.6rem] text-[color:var(--hud-cyan)]">▾</div>
                  </summary>
                  <div className="px-3 pb-3">
                    {[1, 2, 3].map((level) => {
                      const items = byLevel[level as 1 | 2 | 3];
                      if (!items.length) return null;
                      return (
                        <div key={`${cls}-${level}`} className="mt-3">
                          <div className="hud-mono text-[0.7rem] text-[color:var(--hud-cyan)]">Рівень {level}</div>
                          <div className="mt-2 flex flex-col gap-2">
                            {items.map((mission) => (
                              <div key={mission.id} className="border border-[color:var(--hud-amber)]/15 bg-[color:var(--surface-3)]/60 p-2">
                                <div className="flex items-start justify-between gap-2">
                                  <div className="min-w-0">
                                    <div className="hud-mono text-[0.72rem] text-[color:var(--hud-amber)]">{mission.name}</div>
                                    <div className="mt-1 text-[0.6rem] text-[color:var(--muted-foreground)]">{mission.description}</div>
                                  </div>
                                  <div className="hud-mono shrink-0 text-right text-[0.62rem] text-[color:var(--muted-foreground)]">
                                    <div>Ціль: {mission.target}</div>
                                    <div>Нагорода: {mission.mainReward}</div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </div>,
        document.body
      )}

      {reorderOpen && createPortal(<LobbyPlayersPanel onClose={() => setReorderOpen(false)} />, document.body)}
      {completedMissionsOpen && createPortal(<CompletedMissionsModal onClose={() => setCompletedMissionsOpen(false)} />, document.body)}
      {scoreAdminOpen && createPortal(<ScoreAdminModal onClose={() => setScoreAdminOpen(false)} />, document.body)}

      {confirmExit && createPortal(
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/80 px-4 backdrop-blur-sm" role="dialog" aria-modal="true" onClick={() => setConfirmExit(false)}>
          <div
            className="hud-panel-corners-4 relative w-full max-w-sm border border-[color:var(--hud-amber)]/60 bg-[color:var(--surface-2)] p-5"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="corner tl" />
            <span className="corner tr" />
            <span className="corner bl" />
            <span className="corner br" />
            <div className="hud-title text-lg text-[color:var(--hud-amber)]">// ВИХІД?</div>
            <p className="hud-mono mt-2 text-sm text-[color:var(--foreground)]">
              Ви впевнені? Ваш обліковий запис залишиться в сесії і ви зможете повернутись.
            </p>
            <div className="mt-4 flex gap-2">
              <button onClick={() => { sfx.back(); setConfirmExit(false); }} className="hud-btn hud-btn-ghost flex-1">Скасувати</button>
              <button onClick={() => { setConfirmExit(false); logout(); }} className="hud-btn hud-btn-danger flex-1">Вийти</button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </>
  );
}

const HEADER_CONTENT_H = 52; // висота контенту хедера в px
const STATUS_BAR_INNER_HEIGHT = "0rem";
export const STATUS_BAR_HEIGHT = `calc(env(safe-area-inset-top) + ${STATUS_BAR_INNER_HEIGHT})`;
const HEADER_OFFSET = STATUS_BAR_HEIGHT;
const HEADER_INNER_HEIGHT = `calc(12px + 0.5rem + ${HEADER_CONTENT_H}px)`;
const HEADER_TOTAL_HEIGHT = `calc(${HEADER_OFFSET} + ${HEADER_INNER_HEIGHT})`;

export function HudHeader({ title, showStickyTitle, headerRef }: { title: string; showStickyTitle: boolean; headerRef?: React.RefObject<HTMLElement | null> }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(() => setVisible(true), 40);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <header
      ref={headerRef}
      className={`fixed inset-x-0 z-40 border-b border-[color:var(--hud-amber)]/30 bg-[color:var(--surface-2)] transition-all duration-300 ease-out ${visible ? "translate-y-0 opacity-100" : "-translate-y-3 opacity-0 pointer-events-none"}`}
      style={{
        top: HEADER_OFFSET,
        paddingTop: "12px",
        paddingBottom: "0.5rem",
        paddingLeft: "max(0.75rem, env(safe-area-inset-left))",
        paddingRight: "max(0.75rem, env(safe-area-inset-right))",
      }}
    >
      <div className="relative mx-auto flex min-h-[52px] items-center justify-center px-3" style={{ minHeight: `${HEADER_CONTENT_H}px` }}>
        <div className="absolute left-0 top-0 bottom-0 flex items-center">
          <BurgerMenu />
        </div>

        <div
          className={[
            "hud-title border border-[color:var(--hud-amber)]/40 px-3 py-1 text-[color:var(--hud-amber)] transition-all duration-200",
            showStickyTitle
              ? "opacity-100 translate-y-0"
              : "opacity-0 -translate-y-1 pointer-events-none",
          ].join(" ")}
        >
          {title}
        </div>

        <div className="absolute right-0 top-0 bottom-0 flex items-center">
          <HeaderTimer />
        </div>
      </div>
    </header>
  );
}

const NAV_ITEMS: { id: Screen; label: string; icon: typeof ListTodo }[] = [
  { id: "missions", label: "Місії", icon: ListTodo },
  { id: "upgrades", label: "Прокачки", icon: TrendingUp },
  { id: "news", label: "Новини", icon: Radar },
  { id: "score", label: "Бали", icon: BarChart3 },
];

export function BottomNav() {
  const { screen, go } = useKpk();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(() => setVisible(true), 40);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <nav
      className={`fixed inset-x-0 bottom-0 z-40 flex flex-row flex-nowrap items-stretch gap-1.5 border-t border-[color:var(--hud-amber)]/30 bg-[color:var(--surface-2)] overflow-x-auto transition-all duration-300 ease-out ${visible ? "translate-y-0 opacity-100" : "translate-y-3 opacity-0 pointer-events-none"}`}
      style={{
        paddingTop: "0",
        paddingBottom: "env(safe-area-inset-bottom)",
        paddingLeft: "calc(6px + env(safe-area-inset-left))",
        paddingRight: "calc(6px + env(safe-area-inset-right))",
        height: `calc(${HEADER_INNER_HEIGHT} + env(safe-area-inset-bottom))`,
      }}
    >
      {NAV_ITEMS.map((item) => {
        const active = screen === item.id;
        return (
          <button
            key={item.id}
            onClick={() => { sfx.click(); go(item.id); }}
            aria-label={item.label}
            className={active ? "hud-nav-btn-active" : "hud-nav-btn-inactive"}
            style={{
              flex: "1 1 0%",
              minWidth: "0",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: "2px",
              height: "100%",
              padding: "0",
              minHeight: "0",
              marginTop: "-1px",
              whiteSpace: "nowrap",
              boxSizing: "border-box",
              color: active ? "var(--hud-amber)" : "var(--muted-foreground)",
              borderTop: "2px solid transparent",
              background: "transparent",
              cursor: "pointer",
              fontSize: "0.95rem",
            }}
          >
            <item.icon size={20} strokeWidth={1.75} />
            <span className="hud-mono" style={{ fontSize: "0.7rem", letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 700 }}>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

const HeaderVisibilityContext = createContext<{
  headerRef: React.RefObject<HTMLElement | null>;
  setTitleVisible: (v: boolean) => void;
} | null>(null);

export function AppShell({ children }: { children: ReactNode }) {
  const { screen } = useKpk();
  const headerRef = useRef<HTMLElement | null>(null);
  const [titleVisible, setTitleVisible] = useState(true);
  const title = SCREEN_TITLES[screen] ?? "";

  return (
    <HeaderVisibilityContext.Provider value={{ headerRef, setTitleVisible }}>
      <HudHeader title={title} showStickyTitle={!titleVisible} headerRef={headerRef} />
      {children}
      <BottomNav />
    </HeaderVisibilityContext.Provider>
  );
}

export function ScreenShell({ children }: { children: ReactNode; title?: string }) {
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const titleSentinelRef = useRef<HTMLDivElement | null>(null);
  const ctx = useContext(HeaderVisibilityContext);

  useEffect(() => {
    const scrollEl = scrollRef.current;
    const headerEl = ctx?.headerRef.current;
    if (!scrollEl || !headerEl || !ctx) return;

    const titleElement = scrollEl.querySelector<HTMLElement>("h2.hud-title, div.hud-title, span.hud-title");
    const target = titleElement ?? titleSentinelRef.current;
    if (!target) return;

    const updateVisibility = () => {
      const titleRect = target.getBoundingClientRect();
      const headerRect = headerEl.getBoundingClientRect();
      ctx.setTitleVisible(titleRect.bottom > headerRect.bottom + 1);
    };

    updateVisibility();
    let frame = 0;
    const onScroll = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(updateVisibility);
    };

    scrollEl.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      scrollEl.removeEventListener("scroll", onScroll);
    };
  }, [ctx]);

  return (
    <div
      ref={scrollRef}
      className="hud-scroll"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        overflowY: "auto",
        overflowX: "hidden",
        WebkitOverflowScrolling: "touch",
        paddingTop: HEADER_TOTAL_HEIGHT,
        paddingBottom: `calc(${HEADER_INNER_HEIGHT} + env(safe-area-inset-bottom))`,
        paddingLeft: "env(safe-area-inset-left)",
        paddingRight: "env(safe-area-inset-right)",
        zIndex: 10,
      }}
    >
      <div ref={titleSentinelRef} className="h-px" />
      <div className="px-3 py-4 sm:px-6 sm:py-6" style={{ opacity: 0, animation: "hud-screen-in 0.45s cubic-bezier(0.2,0.8,0.2,1) 0.05s both" }}>
        {children}
      </div>
    </div>
  );
}

export function StatChip({ label, value, color }: { label: string; value: ReactNode; color?: string }) {
  return (
    <div className="hud-panel-corners-4 relative border border-[color:var(--hud-amber)]/30 bg-[color:var(--surface-3)]/70 px-3 py-1.5 hud-mono text-xs">
      <span className="corner tl" />
      <span className="corner tr" />
      <span className="corner bl" />
      <span className="corner br" />
      <span className="hud-label mr-2 text-[0.6rem]" style={{ color }}>{label}</span>
      <span className="tabular-nums" style={{ color: color ?? "var(--foreground)" }}>{value}</span>
    </div>
  );
}
