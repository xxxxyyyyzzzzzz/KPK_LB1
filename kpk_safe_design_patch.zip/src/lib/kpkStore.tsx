import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  DEFAULT_ACTION_POINTS,
  TURN_DURATION_SECONDS,
  TOTAL_NEWS_ROUNDS,
  TIER_LIMITS,
  UPGRADES,
  MISSION_CLASSES,
  generateAllMissions,
  generateNews,
  type Mission,
  type Screen,
  type UpgradeCategory,
  type NewsEntry,
} from "./kpkData";
import { sfx } from "./sounds";
import { useServerTimeOffset } from "@/hooks/useServerTimeOffset";
import { generatePlayerId, generateRoomCode } from "./firebase";
import { makePlayer, makeSession, type PlayerState, type PlayerSlot, type SessionState } from "./sessionSchema";
import { readSession, txSession, useSession, writeSession, pruneExpiredTestSessions } from "@/hooks/useSession";

type User = { nickname: string; faction: string };

type ActionPoints = {
  active: number; activeMax: number;
  attack: number; attackMax: number;
  build: number; buildMax: number;
};

type HistoryEntry = { nickname: string; reason: string; reward: number; currency: number };

type PurchaseResult = { ok: boolean; reason?: string };

export type RoomResult = { ok: boolean; reason?: string; code?: string };

type KpkState = {
  // navigation
  screen: Screen;
  prevScreen: Screen | null;

  // player
  user: User | null;
  totalScore: number;
  level1: number; level2: number; level3: number;
  currency: number;
  currencyEarnedThisTurn: number;

  // news / rounds / turns
  newsIndex: 1 | 2 | 3 | 4;
  roundInNews: 1 | 2 | 3 | 4;
  turnInRound: number; // 1..(playersCount+1)
  round: 1 | 2 | 3 | 4; // alias for backward compatibility
  turn: number; // alias for backward compatibility
  // sessionSeconds and turnSeconds moved to TimerTickContext to avoid
  // forcing whole-app re-renders on each tick
  sessionStartedAt: number | null;
  sessionTimerRunning: boolean;
  turnRunning: boolean;

  // ap / replacements
  ap: ActionPoints;
  global_replacements_left: number;  // 0-2, обнуляється на 2 на початку ходу
  unlockedClasses: { "1": string[]; "2": string[]; "3": string[] };

  // missions
  slots: PlayerSlot[];
  completedIds: number[];
  missionsByLevel: Record<1 | 2 | 3, Mission[]>;
  allMissions: Mission[];
  getMission: (id: number | null) => Mission | null;

  // upgrades
  upgrades: string[];
  upgradePoints: number;
  canPurchase: (id: string) => PurchaseResult;
  purchaseUpgrade: (id: string) => PurchaseResult;
  cancelUpgrade: (id: string) => void;

  // news
  news: NewsEntry[];
  history: HistoryEntry[];

  // actions
  login: (u: User) => void;
  createGame: (u: User, opts?: { isTest?: boolean }) => Promise<RoomResult>;
  joinGame: (code: string, u: User) => Promise<RoomResult>;
  rejoinAs: (code: string, existingPid: string) => Promise<RoomResult>;
  roomCode: string | null;
  playerId: string | null;
  isHost: boolean;
  players: { id: string; nickname: string; faction: string; completed_ids?: number[] }[];
  sessionPlayers: {
    id: string; nickname: string; faction: string;
    score: number; level1: number; level2: number; level3: number; currency: number;
  }[];
  activePlayerId: string | null;
  isMyTurn: boolean;
  awaitingNewsAck: boolean;
  ackNews: () => void;
  takenFactions: (code: string) => Promise<string[]>;
  status: "waiting" | "active" | "finished";
  startGame: () => Promise<void>;
  reorderPlayers: (order: string[]) => Promise<void>;
  leaveSession: () => void;
  logout: () => void;
  go: (s: Screen) => void;
  toggleSessionTimer: () => void;
  setAP: (k: keyof ActionPoints, v: number) => void;
  toggleTurn: () => void;
  nextPlayer: () => void;
  updateSlotProgress: (slotIndex: number, delta: number) => void;
  completeSlot: (slotIndex: number) => Promise<{ ok: boolean; reason?: string }>;
  startReplaceConfirm: (slotIndex: number) => void;
  startBrowseClass: (slotIndex: number) => void;
  selectBrowseClass: (slotIndex: number, cls: string) => void;
  startBrowseSameClass: (slotIndex: number) => void;
  backToClassBrowse: (slotIndex: number) => void;
  cancelBrowse: (slotIndex: number) => void;
  confirmMissionSelection: (slotIndex: number, missionId: number) => Promise<boolean>;
  debugBypassTurnLock: boolean;
  setDebugBypassTurnLock: (v: boolean) => void;
  debugAdjustScore: (targetPlayerId: string, field: "score" | "level1_score" | "level2_score" | "level3_score" | "currency", delta: number) => void;
  useLegacyNewsSpawn: boolean;
  setUseLegacyNewsSpawn: (v: boolean) => void;
  isTestSession: boolean;
  cheatGenerateNews: () => void;
  cheatAddScore: (playerId: string, level: 1 | 2 | 3) => void;
};

const KpkContext = createContext<KpkState | null>(null);
const TimerTickContext = createContext<{ turnSeconds: number; sessionSeconds: number }>({ turnSeconds: 0, sessionSeconds: 0 });
export function useTimerTick() { return useContext(TimerTickContext); }

const MAX_EVENTS = 30;
function pruneEvents(events: Record<string, any> | undefined): Record<string, any> {
  const entries = Object.entries(events ?? {});
  if (entries.length <= MAX_EVENTS) return events ?? {};
  entries.sort((a, b) => (b[1].ts ?? 0) - (a[1].ts ?? 0));
  return Object.fromEntries(entries.slice(0, MAX_EVENTS));
}

const slotLevel = (i: number) => ((i % 3) + 1) as 1 | 2 | 3;

function bonusActiveAP(upgrades: string[]) {
  return upgrades.includes("komanduvannya_2_3") ? 1 : 0;
}
function bonusAttackAP(upgrades: string[]) {
  return upgrades.includes("komanduvannya_2_1") ? 1 : 0;
}
function baseAP(upgrades: string[]): ActionPoints {
  const active = DEFAULT_ACTION_POINTS.active + bonusActiveAP(upgrades);
  const attack = DEFAULT_ACTION_POINTS.attack + bonusAttackAP(upgrades);
  const build = DEFAULT_ACTION_POINTS.build;
  return { active, activeMax: active, attack, attackMax: attack, build, buildMax: build };
}

export function KpkProvider({ children }: { children: ReactNode }) {
  const allMissions = useMemo(() => generateAllMissions(), []);
  const missionsByLevel = useMemo(() => {
    const m: Record<1 | 2 | 3, Mission[]> = { 1: [], 2: [], 3: [] };
    for (const x of allMissions) m[x.level].push(x);
    return m;
  }, [allMissions]);

  const [screen, setScreen] = useState<Screen>("login");
  const [prevScreen, setPrev] = useState<Screen | null>(null);
  const [roomCode, setRoomCode] = useState<string | null>(null);
  const [playerId, setPlayerId] = useState<string | null>(null);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [sessionStartedAt, setSessionStartedAt] = useState<number | null>(null);
  const [sessionTimerRunning, setSessionTimerRunning] = useState(false);
  const [debugBypassTurnLock, setDebugBypassTurnLock] = useState(false);

  const session = useSession(roomCode);
  const useLegacyNewsSpawn = session?.use_legacy_news_spawn ?? false;
  const isTestSession = !!session?.is_test;
  const me: PlayerState | null = session && playerId ? session.players?.[playerId] ?? null : null;

  const serverTimeOffset = useServerTimeOffset();
  const serverNow = () => Date.now() + serverTimeOffset;

  const warnRef = useRef(false);

  // session timer
  useEffect(() => {
    if (!session?.session_started_at) return;
    if (sessionStartedAt !== session.session_started_at) {
      setSessionStartedAt(session.session_started_at);
      setSessionSeconds(Math.floor((serverNow() - session.session_started_at) / 1000));
      setSessionTimerRunning(true);
    }
  }, [session?.session_started_at, sessionStartedAt]);

  useEffect(() => {
    if (!sessionStartedAt || !sessionTimerRunning) return;
    setSessionSeconds(Math.floor((serverNow() - sessionStartedAt) / 1000));
    const id = setInterval(() => {
      setSessionSeconds(Math.floor((serverNow() - sessionStartedAt) / 1000));
    }, 1000);
    return () => clearInterval(id);
  }, [sessionStartedAt, sessionTimerRunning]);

  useEffect(() => {
    if (session?.status === "active" && session?.session_started_at && !sessionTimerRunning) {
      setSessionTimerRunning(true);
    }
  }, [session?.status, session?.session_started_at, sessionTimerRunning]);

  const toggleSessionTimer = useCallback(() => {
    if (!sessionStartedAt) {
      const now = serverNow();
      setSessionStartedAt(now);
      setSessionSeconds(0);
      setSessionTimerRunning(true);
      return;
    }
    setSessionTimerRunning((current) => !current);
  }, [sessionStartedAt]);

  const setUseLegacyNewsSpawn = useCallback((value: boolean) => {
    if (!roomCode) return;
    txSession(roomCode, (cur) => cur ? ({ ...cur, use_legacy_news_spawn: value }) : undefined);
  }, [roomCode]);

  // ── TURN TIMER: кожен клієнт рахує локально від turn_end_at, хост для цього не потрібен ──
  const isHost = !!session && !!playerId && session.host_id === playerId;

  const [nowTick, setNowTick] = useState(serverNow());
  useEffect(() => {
    if (!session?.turn_running) return;
    setNowTick(serverNow());
    const id = setInterval(() => setNowTick(serverNow()), 1000);
    return () => clearInterval(id);
  }, [session?.turn_running, serverTimeOffset]);

  // When returning from background, immediately refresh nowTick using server time
  useEffect(() => {
    const onVis = () => { if (typeof document !== 'undefined' && document.visibilityState === 'visible') setNowTick(serverNow()); };
    if (typeof document !== 'undefined') document.addEventListener('visibilitychange', onVis);
    return () => { if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', onVis); };
  }, [serverTimeOffset]);

  const turnSeconds = session
    ? (session.turn_running && session.turn_end_at
        ? Math.max(0, Math.round((session.turn_end_at - nowTick) / 1000))
        : (session.turn_remaining_seconds ?? TURN_DURATION_SECONDS))
    : TURN_DURATION_SECONDS;
  const turnRunning = session?.turn_running ?? false;

  // Коли час ходу вичерпується — БУДЬ-ЯКИЙ клієнт (не лише хост) один раз пише
  // turn_running:false у базу. Безпечно: txSession — справжня Firebase-транзакція
  // з автоповтором; якщо кілька клієнтів спрацюють одночасно, пройде лише перший
  // запис, решта побачать turn_running вже false і нічого не запишуть.
  useEffect(() => {
    if (!session?.turn_running || !session.turn_end_at || !roomCode) return;
    const msLeft = session.turn_end_at - serverNow();
    const id = setTimeout(() => {
      txSession(roomCode, (cur) => {
        if (!cur || !cur.turn_running || !cur.turn_end_at) return undefined;
        if (cur.turn_end_at > serverNow()) return undefined;
        return { ...cur, turn_running: false, turn_remaining_seconds: 0 };
      });
    }, Math.max(0, msLeft));
    return () => clearTimeout(id);
  }, [session?.turn_running, session?.turn_end_at, roomCode, serverTimeOffset]);

  // SFX for timer transitions (local)
  useEffect(() => {
    if (!session) return;
    if (turnSeconds === 30 && !warnRef.current) { warnRef.current = true; sfx.notify(); }
    if (turnSeconds === 0) { sfx.alarm(); warnRef.current = false; }
    if (turnSeconds > 0 && turnSeconds % 60 === 0) sfx.tick();
  }, [turnSeconds, session]);

  const getMission = useCallback(
    (id: number | null) => (id == null ? null : allMissions.find((m) => m.id === id) ?? null),
    [allMissions],
  );

  // Derived view of "me" + session
  const user: User | null = me ? { nickname: me.nickname, faction: me.faction } : null;
  const totalScore = me?.score ?? 0;
  const level1 = me?.level1_score ?? 0;
  const level2 = me?.level2_score ?? 0;
  const level3 = me?.level3_score ?? 0;
  const currency = me?.currency ?? 0;
  const currencyEarnedThisTurn = me?.currency_earned_this_turn ?? 0;
  const news = session?.news ?? [];
  const upgradesList = Object.keys(me?.upgrades ?? {});
  const slots: PlayerSlot[] = me?.slots ?? [];
  const completedIds = me?.completed_ids ?? [];
  const global_replacements_left = me?.global_replacements_left ?? 0;
  const unlockedClasses = me?.unlocked_classes ? {
    "1": me.unlocked_classes["1"] ?? [...MISSION_CLASSES],
    "2": me.unlocked_classes["2"] ?? [],
    "3": me.unlocked_classes["3"] ?? [],
  } : { "1": [...MISSION_CLASSES], "2": [], "3": [] };
  const ap: ActionPoints = me ? {
    active: me.action_points.active, activeMax: me.action_points.active_max,
    attack: me.action_points.attack, attackMax: me.action_points.attack_max,
    build: me.action_points.build, buildMax: me.action_points.build_max,
  } : baseAP([]);
  const newsIndex = (session?.newsIndex ?? session?.round ?? 1) as 1 | 2 | 3 | 4;
  const roundInNews = (session?.roundInNews ?? 1) as 1 | 2 | 3 | 4;
  const playersCount = Math.max(1, session?.player_order?.length ?? Object.keys(session?.players ?? {}).length);
  const turnInRound = session?.turnInRound ?? 1;
  const round = newsIndex;
  const turn = ((roundInNews - 1) * (playersCount + 1)) + turnInRound;
  /* turnSeconds/turnRunning are derived above from turn_end_at/turn_remaining_seconds */
  const history: HistoryEntry[] = useMemo(() => {
    const ev = session?.events ?? {};
    return Object.values(ev)
      .sort((a, b) => b.ts - a.ts)
      .slice(0, 20)
      .map((e) => ({
        nickname: e.nickname,
        reason: String((e.payload as any).reason ?? e.type),
        reward: Number((e.payload as any).reward ?? 0),
        currency: Number((e.payload as any).currency ?? 0),
      }));
  }, [session?.events]);

  const players = useMemo(() => {
    if (!session) return [];
    const order = session.player_order?.length ? session.player_order : Object.keys(session.players ?? {});
    return order.map((id) => ({
      id,
      nickname: session.players[id]?.nickname ?? "—",
      faction: session.players[id]?.faction ?? "",
      completed_ids: session.players[id]?.completed_ids ?? [],
    }));
  }, [session]);

  const sessionPlayers = useMemo(() => {
    if (!session) return [];
    const ids = Object.keys(session.players ?? {});
    const rows = ids.map((id) => {
      const p = session.players[id]!;
      return {
        id,
        nickname: p.nickname,
        faction: p.faction,
        score: p.score ?? 0,
        level1: p.level1_score ?? 0,
        level2: p.level2_score ?? 0,
        level3: p.level3_score ?? 0,
        currency: p.currency ?? 0,
      };
    });
    rows.sort((a, b) => b.score - a.score);
    return rows;
  }, [session]);

  const activePlayerId = session?.active_player_id ?? null;
  const isMyTurn = !!playerId && !!activePlayerId && activePlayerId === playerId;
  const awaitingNewsAck = !!session?.awaiting_news_ack;

  // ── Upgrades: pure validation helpers (used both for UI and inside tx) ──
  const upgradePoints = level1 + level2 + level3;

  function validateUpgrade(p: PlayerState, id: string, currentRound: number, ownTurnLocked: boolean): PurchaseResult {
    const u = UPGRADES[id];
    if (!u) return { ok: false, reason: "Невідома прокачка" };
    if (ownTurnLocked) return { ok: false, reason: "Не можна купувати прокачки у свій хід" };
    if (p.upgrades?.[id]) return { ok: false, reason: "Вже куплено" };
    const owned = Object.keys(p.upgrades ?? {});
    const tierCountRegular = (t: 1 | 2 | 3) =>
      owned.filter((x) => UPGRADES[x]?.tier === t && UPGRADES[x]?.category !== "Командування").length;
    const inCatTier = (cat: UpgradeCategory, t: 1 | 2 | 3) =>
      owned.some((x) => UPGRADES[x]?.category === cat && UPGRADES[x]?.tier === t);
    if (u.category === "Командування") {
      if (currentRound < u.tier) return { ok: false, reason: `Доступно з раунду ${u.tier}` };
      if (tierCountRegular(u.tier) < TIER_LIMITS[u.tier]) return { ok: false, reason: `Спершу заповніть ліміт тіру ${u.tier}` };
      if (inCatTier(u.category, u.tier)) return { ok: false, reason: "Гілка зайнята" };
      if (p.komanduvannya_changed_round === currentRound) return { ok: false, reason: "Вже змінено цієї новини" };
      return { ok: true };
    }
    if (tierCountRegular(u.tier) >= TIER_LIMITS[u.tier]) return { ok: false, reason: `Ліміт тіру ${u.tier}` };
    if (inCatTier(u.category, u.tier)) return { ok: false, reason: "Гілка зайнята" };
    if (u.tier >= 2 && !inCatTier(u.category, 1)) return { ok: false, reason: "Потрібна tier-1 у цій категорії" };
    if (u.tier === 3 && !inCatTier(u.category, 2)) return { ok: false, reason: "Потрібна tier-2 у цій категорії" };
    const score = u.tier === 1 ? p.level1_score : u.tier === 2 ? p.level2_score : p.level3_score;
    if (score < u.cost) return { ok: false, reason: `Недостатньо балів рівня ${u.tier}` };
    return { ok: true };
  }

  const canPurchase = useCallback((id: string): PurchaseResult => {
    if (!me) return { ok: false, reason: "Немає сесії" };
    const ownTurnLocked = isMyTurn && !debugBypassTurnLock;
    return validateUpgrade(me, id, newsIndex, ownTurnLocked);
  }, [me, newsIndex, isMyTurn, debugBypassTurnLock]);

  const purchaseUpgrade = useCallback((id: string): PurchaseResult => {
    if (!roomCode || !playerId) { sfx.deny(); return { ok: false, reason: "Немає сесії" }; }
    // optimistic check
    const pre = canPurchase(id);
    if (!pre.ok) { sfx.deny(); return pre; }
    // fire-and-forget atomic tx
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      const ownTurnLocked = cur.active_player_id === playerId && !debugBypassTurnLock;
      const currentRound = (cur.newsIndex ?? cur.round ?? 1) as number;
      const v = validateUpgrade(p, id, currentRound, ownTurnLocked);
      if (!v.ok) return undefined;
      const u = UPGRADES[id];
      const np: PlayerState = {
        ...p,
        upgrades: { ...(p.upgrades ?? {}), [id]: true as const },
        komanduvannya_changed_round: u.category === "Командування" ? currentRound : p.komanduvannya_changed_round,
        level1_score: p.level1_score - (u.tier === 1 ? u.cost : 0),
        level2_score: p.level2_score - (u.tier === 2 ? u.cost : 0),
        level3_score: p.level3_score - (u.tier === 3 ? u.cost : 0),
        action_points: {
          ...p.action_points,
          active_max: p.action_points.active_max + (id === "komanduvannya_2_3" ? 1 : 0),
          active: p.action_points.active + (id === "komanduvannya_2_3" ? 1 : 0),
          attack_max: p.action_points.attack_max + (id === "komanduvannya_2_1" ? 1 : 0),
          attack: p.action_points.attack + (id === "komanduvannya_2_1" ? 1 : 0),
        },
      };
      const ts = Date.now();
      return {
        ...cur,
        players: { ...cur.players, [playerId]: np },
        events: { ...pruneEvents(cur.events), [`e_${ts}_${id}`]: {
          ts, player_id: playerId, nickname: p.nickname,
          type: "upgrade", payload: { reason: `Прокачка: ${UPGRADES[id].name}`, upgrade_id: id, reward: 0 },
        }},
      };
    }).then((r) => { if (r.ok) sfx.confirm(); else sfx.deny(); });
    return { ok: true };
  }, [roomCode, playerId, canPurchase, debugBypassTurnLock]);

  const cancelUpgrade = useCallback((id: string) => {
    if (!roomCode || !playerId) { sfx.deny(); return; }
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      const u = UPGRADES[id];
      if (!u || !p.upgrades?.[id]) return undefined;
      const owned = Object.keys(p.upgrades);
      const toRemove = new Set<string>([id]);
      if (u.category !== "Командування") {
        for (const x of owned) {
          const ux = UPGRADES[x];
          if (ux && ux.category === u.category && ux.tier > u.tier) toRemove.add(x);
        }
      }
      const newUpgrades = { ...p.upgrades };
      let apDelta = { active_max: 0, active: 0, attack_max: 0, attack: 0 };
      for (const rid of toRemove) {
        delete newUpgrades[rid];
        if (rid === "komanduvannya_2_3") { apDelta.active_max -= 1; apDelta.active -= 1; }
        if (rid === "komanduvannya_2_1") { apDelta.attack_max -= 1; apDelta.attack -= 1; }
      }
      const currentRound = (cur.newsIndex ?? cur.round ?? 1) as number;
      const np: PlayerState = {
        ...p,
        upgrades: newUpgrades,
        komanduvannya_changed_round: u.category === "Командування" ? currentRound : p.komanduvannya_changed_round,
        action_points: {
          ...p.action_points,
          active_max: Math.max(0, p.action_points.active_max + apDelta.active_max),
          active: Math.max(0, p.action_points.active + apDelta.active),
          attack_max: Math.max(0, p.action_points.attack_max + apDelta.attack_max),
          attack: Math.max(0, p.action_points.attack + apDelta.attack),
        },
      };
      return { ...cur, players: { ...cur.players, [playerId]: np } };
    }).then((r) => { if (r.ok) sfx.click(); else sfx.deny(); });
  }, [roomCode, playerId]);

  // ── Missions ──
  const pickNewMissionId = useCallback((level: 1 | 2 | 3, excludeIds: Set<number>) => {
    const pool = missionsByLevel[level].filter((m) => !excludeIds.has(m.id));
    if (!pool.length) return null;
    return pool[Math.floor(Math.random() * pool.length)].id;
  }, [missionsByLevel]);

  const updateSlotProgress = useCallback((slotIndex: number, delta: number) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      const slots = (p.slots ?? []).map((s) => {
        if (s.slot_index !== slotIndex) return s;
        const m = allMissions.find((mm) => mm.id === s.mission_id);
        const max = m?.target ?? 0;
        return { ...s, current_progress: Math.max(0, Math.min(max, s.current_progress + delta)) };
      });
      return { ...cur, players: { ...cur.players, [playerId]: { ...p, slots } } };
    });
  }, [roomCode, playerId, allMissions]);

  // completeMission(roomCode, playerId, missionId) — atomic Firebase transaction
  const completeMissionTx = useCallback(async (
    rc: string, pid: string, slotIndex: number,
  ): Promise<{ ok: boolean; reason?: string }> => {
    const result = await txSession(rc, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[pid]; if (!p) return undefined;
      const slot = p.slots.find((s) => s.slot_index === slotIndex);
      const m = slot?.mission_id != null ? allMissions.find((mm) => mm.id === slot.mission_id) : null;
      if (!slot || !m || slot.current_progress < m.target) return undefined;

      const np: PlayerState = {
        ...p,
        score: p.score + m.mainReward,
        currency: p.currency + m.currencyReward,
        currency_earned_this_turn: p.currency_earned_this_turn + m.currencyReward,
        level1_score: p.level1_score + (m.level === 1 ? m.levelReward : 0),
        level2_score: p.level2_score + (m.level === 2 ? m.levelReward : 0),
        level3_score: p.level3_score + (m.level === 3 ? m.levelReward : 0),
        completed_ids: [...(p.completed_ids ?? []), m.id],
      };

      // Розблокування класу для наступного рівня
      np.unlocked_classes = {
        "1": p.unlocked_classes["1"] ?? [...MISSION_CLASSES],
        "2": p.unlocked_classes["2"] ?? [],
        "3": p.unlocked_classes["3"] ?? [],
      };
      if (m.level === 1 && !np.unlocked_classes["2"].includes(m.cls)) {
        np.unlocked_classes["2"] = [...np.unlocked_classes["2"], m.cls];
      } else if (m.level === 2 && !np.unlocked_classes["3"].includes(m.cls)) {
        np.unlocked_classes["3"] = [...np.unlocked_classes["3"], m.cls];
      }

      np.slots = np.slots.map((s) =>
        s.slot_index === slotIndex ? { ...s, mission_id: null, current_progress: 0, browse_stage: null, browse_class: null, candidates_by_class: null } : s,
      );

      const ts = Date.now();
      return {
        ...cur,
        players: { ...cur.players, [pid]: np },
        events: { ...pruneEvents(cur.events), [`e_${ts}_${slotIndex}`]: {
          ts, player_id: pid, nickname: p.nickname,
          type: "mission_complete",
          payload: { reason: `Виконано: ${m.name}`, reward: m.mainReward, currency: m.currencyReward, mission_id: m.id },
        }},
      };
    });
    return { ok: result.ok };
  }, [allMissions]);

  const completeSlot = useCallback(async (slotIndex: number) => {
    if (!roomCode || !playerId) return { ok: false, reason: "missing_context" };
    const r = await completeMissionTx(roomCode, playerId, slotIndex);
    if (r.ok) sfx.confirm(); else sfx.deny();
    return r;
  }, [roomCode, playerId, completeMissionTx]);

  function buildCandidatePool(allMissions: Mission[], p: PlayerState, slotIndex: number, cls: string): number[] {
    const lvl = ((slotIndex % 3) + 1) as 1 | 2 | 3;
    const taken = new Set<number>([...(p.completed_ids ?? []), ...p.slots.map((s) => s.mission_id ?? -1)]);
    const pool = allMissions.filter((mm) => mm.level === lvl && mm.cls === cls && !taken.has(mm.id));
    const candidates: number[] = [];
    const poolCopy = [...pool];
    for (let i = 0; i < 4 && poolCopy.length > 0; i++) {
      const idx = Math.floor(Math.random() * poolCopy.length);
      candidates.push(poolCopy[idx].id);
      poolCopy.splice(idx, 1);
    }
    return candidates;
  }

  const startReplaceConfirm = useCallback((slotIndex: number) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      if ((p.global_replacements_left ?? 0) <= 0) return undefined;
      return { ...cur, players: { ...cur.players, [playerId]: {
        ...p, slots: p.slots.map((s) => s.slot_index === slotIndex ? { ...s, browse_stage: "confirm" as const } : s),
      }}};
    }).then((r) => { if (r.ok) sfx.click(); else sfx.deny(); });
  }, [roomCode, playerId]);

  const startBrowseClass = useCallback((slotIndex: number) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      return { ...cur, players: { ...cur.players, [playerId]: {
        ...p, slots: p.slots.map((s) => s.slot_index === slotIndex ? { ...s, browse_stage: "class" as const, browse_class: null } : s),
      }}};
    }).then((r) => { if (r.ok) sfx.click(); else sfx.deny(); });
  }, [roomCode, playerId]);

  const selectBrowseClass = useCallback((slotIndex: number, cls: string) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      const slot = p.slots.find((s) => s.slot_index === slotIndex);
      if (!slot) return undefined;
      const existing = slot.candidates_by_class?.[cls];
      const candidates = existing && existing.length > 0 ? existing : buildCandidatePool(allMissions, p, slotIndex, cls);
      return { ...cur, players: { ...cur.players, [playerId]: {
        ...p, slots: p.slots.map((s) => s.slot_index === slotIndex ? {
          ...s, browse_stage: "mission" as const, browse_class: cls,
          candidates_by_class: { ...(s.candidates_by_class ?? {}), [cls]: candidates },
        } : s),
      }}};
    }).then((r) => { if (r.ok) sfx.click(); else sfx.deny(); });
  }, [roomCode, playerId, allMissions]);

  const startBrowseSameClass = useCallback((slotIndex: number) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      const slot = p.slots.find((s) => s.slot_index === slotIndex);
      if (!slot) return undefined;
      const currentMission = slot.mission_id != null ? allMissions.find((mm) => mm.id === slot.mission_id) : null;
      if (!currentMission) return undefined;
      const cls = currentMission.cls;
      const existing = slot.candidates_by_class?.[cls];
      const candidates = existing && existing.length > 0 ? existing : buildCandidatePool(allMissions, p, slotIndex, cls);
      return { ...cur, players: { ...cur.players, [playerId]: {
        ...p, slots: p.slots.map((s) => s.slot_index === slotIndex ? {
          ...s, browse_stage: "mission" as const, browse_class: cls,
          candidates_by_class: { ...(s.candidates_by_class ?? {}), [cls]: candidates },
        } : s),
      }}};
    }).then((r) => { if (r.ok) sfx.click(); else sfx.deny(); });
  }, [roomCode, playerId, allMissions]);

  const backToClassBrowse = useCallback((slotIndex: number) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      return { ...cur, players: { ...cur.players, [playerId]: {
        ...p, slots: p.slots.map((s) => s.slot_index === slotIndex ? { ...s, browse_stage: "class" as const } : s),
      }}};
    }).then((r) => { if (r.ok) sfx.click(); else sfx.deny(); });
  }, [roomCode, playerId]);

  const cancelBrowse = useCallback((slotIndex: number) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      return { ...cur, players: { ...cur.players, [playerId]: {
        ...p, slots: p.slots.map((s) => s.slot_index === slotIndex ? { ...s, browse_stage: null, browse_class: null } : s),
      }}};
    }).then((r) => { if (r.ok) sfx.click(); else sfx.deny(); });
  }, [roomCode, playerId]);

  const confirmMissionSelection = useCallback((slotIndex: number, missionId: number): Promise<boolean> => {
    if (!roomCode || !playerId) return Promise.resolve(false);
    return txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const p = cur.players?.[playerId]; if (!p) return undefined;
      if (cur.active_player_id === playerId && !debugBypassTurnLock) return undefined;
      const slot = p.slots.find((s) => s.slot_index === slotIndex);
      if (!slot) return undefined;
      const wasActive = slot.mission_id != null;
      const np = { ...p };
      if (wasActive) {
        if ((p.global_replacements_left ?? 0) <= 0) return undefined;
        np.global_replacements_left = Math.max(0, (p.global_replacements_left ?? 0) - 1);
      }
      np.slots = p.slots.map((s) => s.slot_index === slotIndex ? {
        ...s, mission_id: missionId, current_progress: 0, browse_stage: null, browse_class: null,
      } : s);
      return { ...cur, players: { ...cur.players, [playerId]: np } };
    }).then((r) => { if (r.ok) sfx.confirm(); else sfx.deny(); return r.ok; });
  }, [roomCode, playerId, debugBypassTurnLock]);

  // ── Turn rotation / News round (host engine triggers news on round boundary) ──
  // Сценарій: гравці ходять по черзі за player_order; коли всі N гравців відіграли
  // TURNS_PER_NEWS_ROUND ходів — миттєво виконується «хід ботів/мутантів» (без UI)
  // і генерується наступна порція новин. Після ходу мутантів 4-го раунду —
  // блокуємо UI прапором awaiting_news_ack.
  const nextPlayer = useCallback(() => {
    if (!roomCode) return;
    warnRef.current = false;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const allowed = cur.active_player_id
        ? (cur.active_player_id === playerId || cur.host_id === playerId)
        : cur.host_id === playerId; // хід ботів (active_player_id === null) — далі передає лише хост
      if (!allowed) return undefined;

      const order = cur.player_order?.length ? cur.player_order : Object.keys(cur.players ?? {});
      const playersCount = Math.max(1, order.length);
      const currentNewsIndex = (cur.newsIndex ?? cur.round ?? 1) as 1 | 2 | 3 | 4;
      const currentRoundInNews = (cur.roundInNews ??
        (cur.turn != null ? (Math.floor(((cur.turn - 1) / playersCount)) + 1) as 1 | 2 | 3 | 4 : 1)) as 1 | 2 | 3 | 4;
      const currentTurnInRound = cur.turnInRound ??
        (cur.turn != null ? ((cur.turn - 1) % playersCount) + 1 : 1);
      const currentIdx = cur.active_player_id ? order.indexOf(cur.active_player_id) : -1;
      const nextTurnInRound = currentTurnInRound + 1;

      let nextNewsIndex = currentNewsIndex;
      let nextRoundInNews = currentRoundInNews;
      let nextActive: string | null = null;
      let nextTurn = nextTurnInRound;
      let news = cur.news;
      let newsSignalTs = cur.news_signal_ts ?? 0;
      let awaitingAck = cur.awaiting_news_ack ?? false;
      let nextStatus: SessionState["status"] = cur.status;
      let nextOrder = [...order];

      if (currentTurnInRound <= playersCount) {
        if (nextTurnInRound <= playersCount) {
          nextActive = order[(currentIdx + 1 + playersCount) % playersCount] ?? order[0] ?? null;
        } else {
          nextActive = null; // ботів/мутантів хід
        }
      } else {
        // Поточний хід був ходом ботів: переходити до нового раунду або новини
        nextTurn = 1;
        if (currentRoundInNews < TOTAL_NEWS_ROUNDS) {
          nextRoundInNews = (currentRoundInNews + 1) as 1 | 2 | 3 | 4;
          nextActive = order[0] ?? null;
        } else {
          if (currentNewsIndex >= TOTAL_NEWS_ROUNDS) {
            nextStatus = "finished";
            awaitingAck = true;
            nextActive = null;
          } else {
            nextNewsIndex = (currentNewsIndex + 1) as 1 | 2 | 3 | 4;
            nextRoundInNews = 1;
            // Порядок гравців (хто за ким) встановлює хост і він незмінний —
            // фізичне розміщення на карті. Перетасовуємо ЛИШЕ те, з кого з них
            // починається новий цикл (ротація по колу), не сам порядок.
            {
              const rotateStart = Math.floor(Math.random() * order.length);
              nextOrder = [...order.slice(rotateStart), ...order.slice(0, rotateStart)];
            }
            news = generateNews(nextNewsIndex, cur.use_legacy_news_spawn ?? false);
            newsSignalTs = Date.now();
            nextActive = nextOrder[0] ?? null;
          }
        }
      }

      if (currentTurnInRound <= playersCount && nextTurnInRound > playersCount) {
        // Ми тільки що перейшли на хід ботів
        nextRoundInNews = currentRoundInNews;
      }

      const players = { ...cur.players };
      for (const pid of Object.keys(players)) {
        const p = players[pid];
        const ap = p.action_points;
        const isNewActive = pid === nextActive;
        players[pid] = {
          ...p,
          action_points: {
            ...ap, active: ap.active_max, attack: ap.attack_max, build: ap.build_max,
          },
          global_replacements_left: isNewActive ? 2 : (p.global_replacements_left ?? 0),
          currency_earned_this_turn: 0,
        };
      }

      const ts = Date.now();
      return {
        ...cur,
        status: nextStatus,
        newsIndex: nextNewsIndex,
        roundInNews: nextRoundInNews,
        turnInRound: nextTurn,
        player_order: nextOrder,
        active_player_id: nextActive,
        turn_end_at: null,
        turn_remaining_seconds: TURN_DURATION_SECONDS,
        turn_running: false,
        news,
        news_signal_ts: newsSignalTs,
        awaiting_news_ack: awaitingAck,
        players,
        events: { ...pruneEvents(cur.events), [`e_${ts}_turn`]: {
          ts, player_id: cur.active_player_id ?? "", nickname: players[cur.active_player_id ?? ""]?.nickname ?? "—",
          type: currentTurnInRound > playersCount ? "news_round" : "turn_end",
          payload: {
            reason: currentTurnInRound > playersCount
              ? (awaitingAck ? "Кінець перших новин" : `Раунд ${nextRoundInNews}: новини зони`)
              : "Кінець ходу",
            reward: 0,
          },
        }},
      };
    }).then(() => sfx.confirm());
  }, [roomCode]);

  const cheatGenerateNews = useCallback(() => {
    if (!roomCode || !isTestSession) return;
    txSession(roomCode, (cur) => {
      if (!cur || !cur.is_test) return undefined;
      const currentNewsIndex = (cur.newsIndex ?? cur.round ?? 1) as 1 | 2 | 3 | 4;
      return { ...cur, news: generateNews(currentNewsIndex, cur.use_legacy_news_spawn ?? false) };
    }).then((r) => { if (r.ok) sfx.confirm(); else sfx.deny(); });
  }, [roomCode, isTestSession]);

  const cheatAddScore = useCallback((targetPlayerId: string, level: 1 | 2 | 3) => {
    if (!roomCode || !isTestSession) return;
    txSession(roomCode, (cur) => {
      if (!cur || !cur.is_test) return undefined;
      const p = cur.players?.[targetPlayerId]; if (!p) return undefined;
      return {
        ...cur,
        players: {
          ...cur.players,
          [targetPlayerId]: {
            ...p,
            score: p.score + 1,
            level1_score: p.level1_score + (level === 1 ? 1 : 0),
            level2_score: p.level2_score + (level === 2 ? 1 : 0),
            level3_score: p.level3_score + (level === 3 ? 1 : 0),
          },
        },
      };
    }).then((r) => { if (r.ok) sfx.confirm(); else sfx.deny(); });
  }, [roomCode, isTestSession]);

  // ── Lobby / Room management ──
  const takenFactions = useCallback(async (code: string) => {
    const s = await readSession(code);
    if (!s) return [];
    return Object.values(s.players ?? {}).map((p) => p.faction);
  }, []);

  const createGame = useCallback(async (u: User, opts?: { isTest?: boolean }): Promise<RoomResult> => {
    pruneExpiredTestSessions().catch(() => {});
    let code = generateRoomCode();
    for (let i = 0; i < 5; i++) {
      const existing = await readSession(code);
      if (!existing) break;
      code = generateRoomCode();
    }
    const pid = generatePlayerId();
    const sess = makeSession(code, pid, { isTest: !!opts?.isTest });
    const player = makePlayer(u.nickname, u.faction);
    sess.players[pid] = player;
    sess.player_order = [pid];
    sess.active_player_id = pid;
    sess.status = "waiting";
    await writeSession(code, sess);
    setRoomCode(code);
    setPlayerId(pid);
    setScreen("lobby");
    sfx.confirm();
    return { ok: true, code };
  }, []);

  const joinGame = useCallback(async (code: string, u: User): Promise<RoomResult> => {
    const c = code.trim().toUpperCase();
    const s = await readSession(c);
    if (!s) return { ok: false, reason: "Сесію не знайдено" };
    const taken = Object.values(s.players ?? {}).map((p) => p.faction);
    if (taken.includes(u.faction)) return { ok: false, reason: "Угрупування вже зайняте" };
    if (Object.keys(s.players ?? {}).length >= 4) return { ok: false, reason: "Кімната заповнена (4/4)" };
    const pid = generatePlayerId();
    const player = makePlayer(u.nickname, u.faction);
    await txSession(c, (cur) => {
      if (!cur) return undefined;
      const t = Object.values(cur.players ?? {}).map((p) => p.faction);
      if (t.includes(u.faction)) return undefined;
      return {
        ...cur,
        players: { ...cur.players, [pid]: player },
        player_order: [...(cur.player_order ?? []), pid],
      };
    });
    setRoomCode(c);
    setPlayerId(pid);
    setScreen(s.status === "active" ? "main" : "lobby");
    sfx.confirm();
    return { ok: true, code: c };
  }, []);

  const rejoinAs = useCallback(async (code: string, existingPid: string): Promise<RoomResult> => {
    const c = code.trim().toUpperCase();
    const s = await readSession(c);
    if (!s) return { ok: false, reason: "Сесію не знайдено" };
    if (!s.players?.[existingPid]) return { ok: false, reason: "Гравця не знайдено" };
    setRoomCode(c);
    setPlayerId(existingPid);
    setScreen(s.status === "active" ? "main" : "lobby");
    sfx.confirm();
    return { ok: true, code: c };
  }, []);

  const startGame = useCallback(async () => {
    if (!roomCode) return;
    await txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      const order = cur.player_order?.length ? cur.player_order : Object.keys(cur.players ?? {});
      if (order.length < 1) return undefined;
      return {
        ...cur,
        status: "active",
        active_player_id: order[0],
        newsIndex: 1,
        roundInNews: 1,
        turnInRound: 1,
        player_order: order,
        news: generateNews(1, cur.use_legacy_news_spawn ?? false),
        session_started_at: cur.session_started_at ?? Date.now(),
        news_signal_ts: Date.now(),
        awaiting_news_ack: false,
      };
    });
    setSessionTimerRunning(true);
    sfx.confirm();
  }, [roomCode]);

  const reorderPlayers = useCallback(async (order: string[]) => {
    if (!roomCode || !playerId) return;
    await txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      if (cur.host_id !== playerId) return undefined;
      return { ...cur, player_order: order, active_player_id: order[0] ?? cur.active_player_id };
    });
  }, [roomCode, playerId]);

  const debugAdjustScore = useCallback((targetPlayerId: string, field: "score" | "level1_score" | "level2_score" | "level3_score" | "currency", delta: number) => {
    if (!roomCode || !playerId) return;
    txSession(roomCode, (cur) => {
      if (!cur) return undefined;
      if (cur.host_id !== playerId) return undefined;
      const p = cur.players?.[targetPlayerId]; if (!p) return undefined;
      const next = Math.max(0, (p[field] ?? 0) + delta);
      return { ...cur, players: { ...cur.players, [targetPlayerId]: { ...p, [field]: next } } };
    });
  }, [roomCode, playerId]);

  const ackNews = useCallback(() => {
    if (!roomCode) return;
    setScreen("news");
    // Скидаємо глобальний прапор лише за хостом, щоб не «гасити» модал у інших до їх кліку.
    if (isHost) {
      txSession(roomCode, (cur) => cur ? ({ ...cur, awaiting_news_ack: false }) : undefined);
    }
  }, [roomCode, isHost]);

  // Auto-navigate lobby → loading → main when host starts the game
  useEffect(() => {
    if (!session) return;
    if (session.status === "active" && screen === "lobby") {
      setScreen("session-loading");
    }
  }, [session?.status, screen]);

  // Auto-navigate every player to NewsScreen on each news round bump.
  const lastNewsSignalRef = useRef<number>(0);
  useEffect(() => {
    const ts = session?.news_signal_ts ?? 0;
    if (!ts) return;
    if (ts > lastNewsSignalRef.current) {
      lastNewsSignalRef.current = ts;
      // Уникаємо переходу з логіну/лобі/завантаження: переходимо лише коли вже в грі.
      if (screen !== "login" && screen !== "lobby" && screen !== "session-loading") {
        setScreen("news");
      } else if (session?.status === "active" && screen !== "session-loading") {
        setScreen("news");
      }
    }
  }, [session?.news_signal_ts, session?.status, screen]);

  const value: KpkState = useMemo(() => ({
    screen, prevScreen, user,
    totalScore, level1, level2, level3, currency, currencyEarnedThisTurn,
    newsIndex, roundInNews, turnInRound,
    round, turn, /* sessionSeconds, */ sessionStartedAt, sessionTimerRunning, /* turnSeconds, */ turnRunning,
    ap, global_replacements_left, unlockedClasses,
    slots, completedIds, missionsByLevel, allMissions, getMission,
    upgrades: upgradesList, upgradePoints, canPurchase, purchaseUpgrade, cancelUpgrade,
    news, history,
    login: (u) => { createGame(u); },
    createGame, joinGame, rejoinAs, roomCode, playerId, isHost, players,
    sessionPlayers, activePlayerId, isMyTurn, awaitingNewsAck, ackNews,
    takenFactions,
    status: (session?.status ?? "waiting") as "waiting" | "active" | "finished",
    startGame, reorderPlayers,
    leaveSession: () => {
      setRoomCode(null);
      setPlayerId(null);
      setScreen("login");
      setSessionStartedAt(null);
      setSessionSeconds(0);
      setSessionTimerRunning(false);
      sfx.back();
    },
    logout: () => {
      setRoomCode(null);
      setPlayerId(null);
      setScreen("login");
      setSessionStartedAt(null);
      setSessionSeconds(0);
      setSessionTimerRunning(false);
      sfx.back();
    },
    go: (s) => { setPrev(screen); setScreen(s); },
    toggleSessionTimer,
    setAP: (k, v) => {
      if (!roomCode || !playerId) return;
      const map: Record<string, string> = { active: "active", attack: "attack", build: "build" };
      const field = map[k as string]; if (!field) return;
      txSession(roomCode, (cur) => {
        if (!cur) return undefined;
        const p = cur.players?.[playerId]; if (!p) return undefined;
        return { ...cur, players: { ...cur.players, [playerId]: {
          ...p, action_points: { ...p.action_points, [field]: Math.max(0, v) },
        }}};
      });
    },
    toggleTurn: () => {
      if (!roomCode) return;
      warnRef.current = false;
      txSession(roomCode, (cur) => {
        if (!cur) return undefined;
        // Лише активний гравець може стартувати/паузити свій таймер.
        if (cur.active_player_id && cur.active_player_id !== playerId) return undefined;
        if (cur.turn_running) {
          // Пауза: заморожуємо залишок секунд на момент паузи.
          const remaining = cur.turn_end_at
            ? Math.max(0, Math.round((cur.turn_end_at - serverNow()) / 1000))
            : (cur.turn_remaining_seconds ?? 0);
          return { ...cur, turn_running: false, turn_end_at: null, turn_remaining_seconds: remaining };
        }
        // Відновлення: нова мить закінчення від залишку секунд.
        const remaining = cur.turn_remaining_seconds ?? TURN_DURATION_SECONDS;
        return { ...cur, turn_running: true, turn_end_at: serverNow() + remaining * 1000 };
      });
    },
    nextPlayer,
    updateSlotProgress,
    completeSlot,
    startReplaceConfirm,
    startBrowseClass,
    selectBrowseClass,
    startBrowseSameClass,
    backToClassBrowse,
    cancelBrowse,
    confirmMissionSelection,
    debugBypassTurnLock, setDebugBypassTurnLock, debugAdjustScore,
    useLegacyNewsSpawn, setUseLegacyNewsSpawn,
    isTestSession, cheatGenerateNews, cheatAddScore,
  }), [
    screen, prevScreen, user, totalScore, level1, level2, level3, currency, currencyEarnedThisTurn,
    round, turn, /* sessionSeconds, turnSeconds, */ turnRunning, ap, global_replacements_left, unlockedClasses,
    slots, completedIds, missionsByLevel, allMissions, getMission,
    upgradesList, upgradePoints, canPurchase, purchaseUpgrade, cancelUpgrade, news, history,
    roomCode, playerId, isHost, players, sessionPlayers,
    activePlayerId, isMyTurn, awaitingNewsAck, ackNews,
    takenFactions, createGame, joinGame, rejoinAs,
    session?.status, startGame, reorderPlayers,
    nextPlayer, updateSlotProgress, completeSlot, startReplaceConfirm, startBrowseClass, selectBrowseClass, startBrowseSameClass, backToClassBrowse, cancelBrowse, confirmMissionSelection,
    debugBypassTurnLock, isTestSession, useLegacyNewsSpawn, setUseLegacyNewsSpawn, cheatGenerateNews, cheatAddScore, debugAdjustScore,
  ]);

  return (
    <KpkContext.Provider value={value}>
      <TimerTickContext.Provider value={{ turnSeconds, sessionSeconds }}>
        {children}
      </TimerTickContext.Provider>
    </KpkContext.Provider>
  );
}

export function useKpk() {
  const v = useContext(KpkContext);
  if (!v) throw new Error("useKpk must be used inside KpkProvider");
  const tick = useContext(TimerTickContext);
  return { ...v, sessionSeconds: tick.sessionSeconds, turnSeconds: tick.turnSeconds };
}

export function fmtClock(s: number) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}
export function fmtSession(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
}
