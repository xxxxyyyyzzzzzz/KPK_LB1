import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Add HDR glow touch support to buttons.
 * On touchstart: add hdr-active class for dramatic glow.
 * On touchend: keep glow visible for 300ms then fade.
 */
export function attachHdrTouchGlow(button: HTMLElement) {
  if (!button) return;

  let touchTimer: ReturnType<typeof setTimeout> | null = null;

  const onStart = () => {
    if (touchTimer) clearTimeout(touchTimer);
    button.classList.add("hdr-active");
  };
  const onEnd = () => {
    touchTimer = setTimeout(() => {
      button.classList.remove("hdr-active");
      touchTimer = null;
    }, 300);
  };

  button.addEventListener("touchstart", onStart);
  button.addEventListener("touchend", onEnd);

  return () => {
    if (touchTimer) clearTimeout(touchTimer);
    button.removeEventListener("touchstart", onStart);
    button.removeEventListener("touchend", onEnd);
  };
}

export function formatPoints(value: number): string {
  const rounded = Math.round(value * 10) / 10;
  if (Number.isInteger(rounded)) return String(rounded);
  return String(rounded.toFixed(1)).replace(/\.0$/, "");
}
